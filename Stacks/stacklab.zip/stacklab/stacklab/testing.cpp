#include "StdAfx.h"
#include "testing.h"


testing::testing(void)
{
}


testing::~testing(void)
{
}
