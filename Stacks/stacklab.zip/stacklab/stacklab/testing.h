#pragma once
class testing
{
public:
	testing(void);
	
	~testing(void);
};

