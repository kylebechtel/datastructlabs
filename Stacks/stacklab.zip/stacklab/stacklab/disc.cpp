#include "StdAfx.h"
#include "disc.h"


disc::disc(void)
{
	int size;
}


disc::~disc(void)
{
}
