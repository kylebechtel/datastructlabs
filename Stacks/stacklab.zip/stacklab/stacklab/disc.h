#pragma once
class disc
{
public:
	disc(void);
	~disc(void);
};

