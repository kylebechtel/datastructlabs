#pragma once
#include <vector>
using namespace std;
class bs
{
	int fu;
public:
	bs(void);
	
void max(vector<int>&);
void min(vector<int>&);
void fill(vector<int>&, int);
void peek(vector<int>, int);
void dumb(){system("pause");};

	~bs(void);
};

