#pragma once
#include <string>
#include "Nodes.h"
using namespace std;
class mylist
{
	
public:
	mylist(void);
	void Add(string);
	~mylist(void);
};

