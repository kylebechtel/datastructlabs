#include "StdAfx.h"
#include "mylist.h"


mylist::mylist(void)
{
}





mylist::~mylist(void)
{
}
